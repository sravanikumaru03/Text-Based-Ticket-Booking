package com.bookingapp;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        SeatBooking booking = new SeatBooking();
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nMenu:");
            System.out.println("1. Book Seat");
            System.out.println("2. Cancel Seat");
            System.out.println("3. View Seats");
            System.out.println("4. View Total & Available Seats");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    booking.bookSeat(sc);
                    break;
                case 2:
                    booking.cancelSeat(sc);
                    break;
                case 3:
                    booking.displaySeats();
                    break;
                case 4:
                    booking.viewSeatSummary();
                    break;
                case 5:
                    System.out.println("Thank you for using the Ticket Booking App.");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter 1-5.");
            }
        } while (choice != 5);

        sc.close();
    }
}
