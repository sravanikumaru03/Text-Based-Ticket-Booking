package com.bookingapp;

import java.util.*;

public class SeatBooking {
    boolean[] seats = new boolean[10];
    Scanner sc = new Scanner(System.in);

    public void displaySeats() {
        int totalSeats = seats.length;
        int bookedCount = 0;

        System.out.println("\nAvailable Seats View: (⬜ = Available, ⬛ = Booked)");
        for (int i = 0; i < seats.length; i++) {
            if (seats[i]) {
                System.out.print("⬛ ");
                bookedCount++;
            } else {
                System.out.print("⬜ ");
            }
        }
        System.out.println("\nSeat Numbers       :  1  2  3  4  5  6  7  8  9 10");

        int availableSeats = totalSeats - bookedCount;
        System.out.println("\nTotal Seats     : " + totalSeats);
        System.out.println("Available Seats : " + availableSeats);
        System.out.println("Booked Seats    : " + bookedCount);
    }

    public void bookSeat(Scanner sc) {
        displaySeats();
        System.out.print("\nEnter number of seats to book: ");
        int num = sc.nextInt();

        if (num <= 0) {
            System.out.println("Invalid number of seats.");
            return;
        }

        int[] selectedSeats = new int[num];
        for (int i = 0; i < num; i++) {
            System.out.print("Enter seat number (1-10) for seat " + (i + 1) + ": ");
            selectedSeats[i] = sc.nextInt();
        }

        for (int seatNo : selectedSeats) {
            if (seatNo < 1 || seatNo > 10 || seats[seatNo - 1]) {
                System.out.println("Seat " + seatNo + " is invalid or already booked.");
                return;
            }
        }

        sc.nextLine(); // consume newline
        System.out.print("Enter Name: ");
        String name = sc.nextLine();
        System.out.print("Enter Age: ");
        int age = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Contact: ");
        String contact = sc.nextLine();
        System.out.print("Enter Pickup Point: ");
        String pickup = sc.nextLine();
        System.out.print("Enter Drop Point: ");
        String drop = sc.nextLine();

        for (int seatNo : selectedSeats) {
            seats[seatNo - 1] = true;
        }

        System.out.println("\n🎉 Congratulations! Your ticket is confirmed.");
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Contact: " + contact);
        System.out.println("Pickup Point: " + pickup);
        System.out.println("Drop Point: " + drop);
        System.out.print("Booked Seats: ");
        for (int seatNo : selectedSeats) {
            System.out.print(seatNo + " ");
        }
        System.out.println();
    }

    public void cancelSeat(Scanner sc) {
        displaySeats();
        System.out.print("\nEnter seat number to cancel: ");
        int seatNo = sc.nextInt();

        if (seatNo < 1 || seatNo > 10) {
            System.out.println("Invalid seat number.");
            return;
        }

        if (seats[seatNo - 1]) {
            seats[seatNo - 1] = false;
            System.out.println("Seat " + seatNo + " booking canceled.");
        } else {
            System.out.println("Seat " + seatNo + " is not booked.");
        }
    }

    public void viewSeatSummary() {
        int totalSeats = seats.length;
        int bookedCount = 0;
        for (boolean seat : seats) {
            if (seat) bookedCount++;
        }
        int availableSeats = totalSeats - bookedCount;

        System.out.println("\n===== Seat Summary =====");
        System.out.println("Total Seats     : " + totalSeats);
        System.out.println("Available Seats : " + availableSeats);
        System.out.println("Booked Seats    : " + bookedCount);
        System.out.println("=========================");
    }
}
